var typed = new Typed(".input", {
    strings: ["Fronted Developer", "Software Developer", "Web Developer"],
    typedSpeed: 70,
    backSpeed: 55,
    loop: true
})


