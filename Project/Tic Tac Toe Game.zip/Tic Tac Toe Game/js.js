let boxes = document.querySelectorAll(".box");
let resetbtn = document.querySelector("#reset-btn");
let newbtn = document.querySelector("#New-btn");
let msgcon = document.querySelector(".msg-container");
let msg = document.querySelector("#msg");

let turnO = true; //playerO //playerX

//pattern for winning
const winpattern = [
    [0, 1, 2],
    [0, 3, 6],
    [0, 4, 8],
    [1, 4, 7],
    [2, 5, 8],
    [2, 4, 6],
    [3, 4, 5],
    [6, 7, 8],
];

//resetGame 
const resetGame = () => {
    turnO = true;
    enableBoxes();
    msgcon.classList.add("hide");

};

// box click on box
boxes.forEach((box) => {
    box.addEventListener("click", () => {
        if (turnO) { //play O
            box.innerText = "O";
            turnO = false;
        } else {  //play X
            box.innerText = "X";
            turnO = true;
        }
        box.disabled = true;

        checkWinner();  /// winner function
    });
});

const disabledBoxes = () => {   // after winner box close
    for (let box of boxes) {
        box.disabled = true;   // disable to boxes
    }
}
const enableBoxes = () => {                 // new game start box open
    for (let box of boxes) {
        box.disabled = false;
        box.innerHTML = "";  // inner text emtey
    }
}

//winner show 
const showWinner = (winner) => {
    msg.innerHTML = `Congratulation, Winner is ${winner}`;
    msgcon.classList.remove("hide");
    disabledBoxes();
}

//check winner 
const checkWinner = () => {
    for (let pattern of winpattern) {
        let pos1val = boxes[pattern[0]].innerText;
        let pos2val = boxes[pattern[1]].innerText;
        let pos3val = boxes[pattern[2]].innerText;

        if (pos1val != "" && pos2val != "" && pos3val != "") {
            if (pos1val === pos2val && pos2val === pos3val) {
                showWinner(pos1val);

            }
        }

    }
};

// btn
newbtn.addEventListener("click", resetGame);
resetbtn.addEventListener("click", resetGame);