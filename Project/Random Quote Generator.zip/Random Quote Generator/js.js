document.addEventListener('DOMContentLoaded', function () {
    const quoteContainer = document.getElementById('quote-container');
    const quoteText = document.getElementById('quote');
    const authorText = document.getElementById('author');
    const newQuoteButton = document.getElementById('new-quote');
    const tagSelect = document.getElementById('tag');

    const API_URL = 'https://dummyjson.com/quotes';

    function fetchQuote() {
        const tag = tagSelect.value;
        const url = tag ? `${API_URL}?tags=${tag}` : API_URL;

        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('API request failed');
                }
                return response.json();
            })
            .then(data => {
                if (data && data.quotes && data.quotes.length > 0) {
                    // If the API returns an array of quotes
                    const randomQuote = data.quotes[Math.floor(Math.random() * data.quotes.length)];
                    quoteText.textContent = `"${randomQuote.quote}"`;
                    authorText.textContent = `— ${randomQuote.author}`;
                } else {
                    quoteText.textContent = "Sorry, we couldn't fetch a quote at this time.";
                    authorText.textContent = "";
                }
            })
            .catch(error => {
                quoteText.textContent = "Sorry, we couldn't fetch a quote at this time.";
                authorText.textContent = "";
                console.error("Error fetching quote:", error);
            });
    }

    newQuoteButton.addEventListener('click', fetchQuote);
    tagSelect.addEventListener('change', fetchQuote);

    fetchQuote(); // Initial quote fetch on page load
});
